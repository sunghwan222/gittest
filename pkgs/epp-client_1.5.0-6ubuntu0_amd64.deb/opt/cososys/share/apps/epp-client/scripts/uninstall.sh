#!/bin/bash

## Force the user to run the script with root privileges
if [[ $(whoami) != root ]]; then
		sudo "$0"
		exit $?
fi

distro="$(lsb_release -i | cut -f 2-)"
echo $distro

CONFIGFILE=options.ini
CONFIGPATH=/opt/cososys/share/apps/epp-client
SERVICE="$(which service)"
EPPCLIENTDAEMON=epp-client-daemon-d
YUM="$(which yum)"
CAT="$(which cat)"
ZYPPER="$(which zypper)"
APT="$(which apt-get)"
DPKG="$(which dpkg)"
AWK="$(which awk)"

distro="$(lsb_release -i | cut -f 2-)"


function Remove {
	rm -rf /opt/cososys/
	rm -rf /var/opt/cososys/
	rm -rf /var/log/epp-client/
	rm -f /etc/init.d/epp-client-daemon-d
	killall -TERM epp-client
	rm -f /etc/init.d/check-process.sh
	crontab -u root -l | sed 's/.*check-eppclient-process.sh.*$//g' | sudo crontab -u root -
	sudo killall check-eppclient-process.sh
}

## CentOS
if [ "$distro" == "CentOS" ]; then
    $YUM -y remove --disablerepo=* epp-client-config epp-client-cap-def epp-client cososys-filesystem 
    Remove
    exit
fi

## Fedora 27
if [ "$distro" == "Fedora" ]; then
    $YUM -y remove --disablerepo=* epp-client-config epp-client-cap-def epp-client cososys-filesystem 
    Remove
    exit
fi


## OracleServer
if [ "$distro" == "OracleServer" ]; then
    $YUM -y remove --disablerepo=* epp-client-config epp-client-cap-def epp-client cososys-filesystem 
    Remove
    exit
fi

## OracleServer
if [ "$distro" == "OracleLinux" ]; then
    $YUM -y remove --disablerepo=* epp-client-config epp-client-cap-def epp-client cososys-filesystem 
    Remove
    exit
fi

## RedHat
if [ "$distro" == "RedHatEnterpriseServer" ]; then
    $YUM -y remove --disablerepo=* epp-client-config epp-client-cap-def epp-client cososys-filesystem 
    Remove
    exit
fi

## Ubuntu
if [ "$distro" == "Ubuntu" ]; then
	## Check if epp-client already installed
	EPPINSTALLED="$($DPKG -l | grep epp-client | awk '{print $3}' | head -1)"
	if [ "$EPPINSTALLED" != "" ]; then
		$SERVICE $EPPCLIENTDAEMON stop
		$DPKG --purge epp-client
		$DPKG --purge epp-client-config
		$DPKG --purge epp-client-cap-def
		$DPKG --purge cososys-filesystem
		Remove
		exit 
	fi
	exit
fi

## Linux Mint
if [ "$distro" == "LinuxMint" ]; then
	## Check if epp-client already installed
	EPPINSTALLED="$($DPKG -l | grep epp-client | awk '{print $3}' | head -1)"
	if [ "$EPPINSTALLED" != "" ]; then
		$SERVICE $EPPCLIENTDAEMON stop
		$DPKG --purge epp-client
		$DPKG --purge epp-client-config
		$DPKG --purge epp-client-cap-def
		$DPKG --purge cososys-filesystem
		Remove
	fi
	exit
fi

## Ubuntu
if [ "$distro" == "Zorin" ]; then
	## Check if epp-client already installed
	EPPINSTALLED="$($DPKG -l | grep epp-client | awk '{print $3}' | head -1)"
	if [ "$EPPINSTALLED" != "" ]; then
		$SERVICE $EPPCLIENTDAEMON stop
		$DPKG --purge epp-client
		$DPKG --purge epp-client-config
		$DPKG --purge epp-client-cap-def
		$DPKG --purge cososys-filesystem
		Remove
	fi
	exit
fi

## Ubuntu
if [ "$distro" == "Debian" ]; then
	## Check if epp-client already installed
	EPPINSTALLED="$($DPKG -l | grep epp-client | awk '{print $3}' | head -1)"
	if [ "$EPPINSTALLED" != "" ]; then
		$SERVICE $EPPCLIENTDAEMON stop
		$DPKG --purge epp-client
		$DPKG --purge epp-client-config
		$DPKG --purge epp-client-cap-def
		$DPKG --purge cososys-filesystem
		Remove
		exit 
	fi
	exit
fi


## Suse / OpenSUSE OS distros
if [ "$distro" == "SUSE" ]; then
	$ZYPPER -n remove epp-client-config epp-client-cap-def epp-client cososys-filesystem 
	Remove
	exit
fi

## Suse / OpenSUSE OS distros
if [ "$distro" == "SUSE LINUX" ]; then
	$ZYPPER -n remove epp-client-config epp-client-cap-def epp-client cososys-filesystem 
	Remove
	exit
fi

## Suse / OpenSUSE OS distros
if [ "$distro" == "openSUSE project" ]; then
	$ZYPPER -n remove epp-client-config epp-client-cap-def epp-client cososys-filesystem 
	Remove
	exit
fi

## Suse / OpenSUSE OS distros
if [ "$distro" == "SUSE" ]; then
	$ZYPPER -n remove epp-client-config epp-client-cap-def epp-client cososys-filesystem 
	Remove
	exit
fi

## Fedora 29
if [ `$AWK -F= '/^NAME/{print $2}' /etc/os-release` == 'Fedora' ] ; then
    $YUM -y remove --disablerepo=* epp-client-config epp-client-cap-def epp-client cososys-filesystem 
    Remove
    echo "if fedora"
    exit
fi


