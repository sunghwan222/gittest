#!/usr/bin/env bash
: '
	linux_install_certificates.sh
	Created on: Aug 23, 2019
	Author: razvan

	parameter #1:  
	    -l install  certificates
	    -u uninstall certificates
	parameter #2:  
	    f  Firefox	
	    c  Chrome 
	    i  Chromium 
	    o  Opera / Opera Developer / Opera Beta 
	    t  Thunderbird
	    or any combination of these
'

main() {
	if [[ $DEBUG -eq 0 ]]
	then 
		installCertificates "$@" 1>/dev/null 2>&1
	else 
		installCertificates "$@"
	fi

	exit 0
}


###############################################################################################
# Implementation
###############################################################################################

readonly MACHINE_NAME="$(uname -n)"
readonly CERTIFICATE_FILE="/var/opt/cososys/epp-client/netdlp/cert.pem"
readonly CERTIFICATE_NAME="${MACHINE_NAME} - Endpoint Protector NetDLP"
readonly CURRENT_PATH="$(pwd)"
readonly CERTUTIL="$(command -v certutil)"
readonly USERS="$(users)"
readonly DEBUG=0

########################################
# function for add or delete certificate
# 1 parameter "-l" or "-u"
# 2 parameter PROFILE_PATH
########################################
installCertificate() {
	echo "PATH IS '$2'"
	echo -e "\nEntered 'installCertificate' function"
	echo -e "\nCurrent directory is '$2'\n"

	PATH_PWD=$2

	if [[ "$(find "${PATH_PWD}" -name cert9.db)" != '' ]]
	then
		export NSS_DEFAULT_DB_TYPE=sql
	else 
		export NSS_DEFAULT_DB_TYPE=dbm
	fi

	if [ "$1" == '-l' ]
	then
		${CERTUTIL} -A -n "${CERTIFICATE_NAME}" -t "TC,TC,TC" -d "${PATH_PWD}" -i "${CERTIFICATE_FILE}"
	else
		${CERTUTIL} -D -d "${PATH_PWD}" -n "${CERTIFICATE_NAME}" 1>/dev/null
		if [ $? -ne 0 ]
		then 
			echo -e "Certificate '${CERTIFICATE_NAME}' does not exist. Maybe it was already removed?\n"
		fi
	fi

	echo -e "Exited 'installCertificate' function\n"
}

########################################
# Tools for install certificates 
# 1 parameter "-l" or "-u"
# 2 parameter "f" or "t" or "tf" or "ft"
# 3 parameter profile path
# 4 parameter thunderbird or firefox
# 5 parameter the path of thunderbird or firefox profiles file
########################################
installCertificateUtil() {
	echo "Entered installCertificateUtil with parameters '$1' '$2' '$3' '$4' '$5'."

	PROFILE_PATH=$3
	PROFILES_FILE_PATH=$5
	PROFILES_FILE_PATH="$(dirname ${PROFILES_FILE_PATH})"

	if [ "$(echo '${PROFILE_PATH}' | grep "/")" == '' ]
	then 
		PROFILE_PATH="${PROFILES_FILE_PATH}/${PROFILE_PATH}"
	fi

	echo -e "\n--- entered '$4' folder ---"

	installCertificate "$1" "$PROFILE_PATH"
	
	if [ "$1" == "-l" ]
	then
		echo "Done. Certificate was added successfully for '$4'."
	fi
			
	if [ "$1" == "-u" ]
	then
		echo "Done. Certificate was deleted successfully for '$4'."
	fi
	
	echo -e "\n--- exited '$4' folder ---"
}

########################################
# Install / uninstall certificates
# 1 parameter "-l" or "-u"
# 2 parameter "f" or "t" or "c" or "o" or "i" or any combination of these
########################################
installCertificates() {
	if [ "$EUID" -ne 0 ]
	then
	    echo "Please run as root"
	    exit 1
	fi

	if [ "$#" -ne 2 ]
	then
	    echo "Please insert correct number of parameters."
	    echo "First parameter must to be -l (add new certificate), -u (delete certificate)."
	    echo "Second parameter must to be f (firefox), t (thunderbird), c (chrome), i (chromium), o (opera) or a combination of these."
		exit 1
	fi

	if [ "$1" != "-l" ] && [ "$1" != "-u" ]
	then
	    echo "First parameter must to be -l (add new certificate), -u (delete existing certificate)"
	    exit 1
	fi

	if [[ "$2" != *"f"* ]] && [[ "$2" != *"t"* ]] && [[ "$2" != *"c"* ]] && [[ "$2" != *"o"* ]] && [[ "$2" != *"i"* ]]
	then
	    echo "Second parameter must to be f (firefox), t (thunderbird), c (chrome), i (chromium), o (opera) or a combination of these."
	    exit 1
	fi

	echo "Current path is ${CURRENT_PATH}"
	# firefox
	if [[ "$2" == *"f"* ]]
	then
		FIREFOX_PATH="/home/*/.mozilla/firefox/"

		for i in {1..2}
		do
			FIREFOX_PROFILE_FILE="profiles.ini"
			FIREFOX_PROFILES_FILE_PATH="${FIREFOX_PATH}/${FIREFOX_PROFILE_FILE}"

			for PROFILE in $FIREFOX_PROFILES_FILE_PATH
			do
				if [[ ! -e ${PROFILE} ]]
				then
					continue 
				fi
				# retrieve all profile paths
				FIREFOX_PROFILE_PATHS="$(cat ${PROFILE} | grep ^Path= | sed 's/^Path=//')"
				
				for PROFILE_PATH in $FIREFOX_PROFILE_PATHS
				do
					installCertificateUtil "$1" "$2" "${PROFILE_PATH}" "firefox" "${PROFILE}"
				done
			done

			FIREFOX_PATH="/home/*/snap/*/*/.mozilla/firefox"
		done
	fi
	# end firefox

	# chrome
	if [[ "$2" == *"c"* ]]
	then
		for user in $USERS
		do
			installCertificate "$1" "/home/$user/.pki/nssdb"
		done
	fi
	# end chrome

	# chromium 
	if [[ "$2" == *"i"* ]]
	then 
		for user in $USERS 
		do
			CHROMIUM_PATH="/home/$user/snap/chromium/*/.pki/nssdb"
			for i in {1..2}
			do
				for CERT_PATH in $CHROMIUM_PATH
				do
					if [[ -d ${CERT_PATH} ]]
					then
						installCertificate "$1" "$CERT_PATH"
					fi
				done
				CHROMIUM_PATH="/home/$user/.pki/nssdb"
			done
		done
	fi
	# end chromium

	# opera 
	if [[ "$2" == *"o"* ]]
	then 
		for user in $USERS 
		do
			OPERA_PATH="/home/$user/snap/opera/*/.pki/nssdb"
			for i in {1..2}
			do
				for CERT_PATH in $OPERA_PATH
				do 
					if [[ -d ${CERT_PATH} ]]
					then
						installCertificate "$1" "$CERT_PATH"
					fi
				done
				OPERA_PATH="/home/$user/.pki/nssdb"
			done
		done
	fi

	if [[ "$2" == *"o"* ]]
	then
		for user in $USERS 
		do
			OPERA_DEVELOPER_PATH="/home/$user/snap/opera-developer/*/.pki/nssdb"
			for i in {1..2}
			do
				for CERT_PATH in $OPERA_DEVELOPER_PATH
				do
					if [[ -d ${CERT_PATH} ]]
					then
						installCertificate "$1" "$CERT_PATH"
					fi
				done
				OPERA_DEVELOPER_PATH="/home/$user/.pki/nssdb"
			done
		done
	fi

	if [[ "$2" == *"o"* ]]
	then
	 	for user in $USERS 
		do
			OPERA_BETA_PATH="/home/$user/snap/opera-beta/*/.pki/nssdb"
			for i in {1..2}
			do
				for CERT_PATH in $OPERA_BETA_PATH
				do
					if [[ -d ${CERT_PATH} ]]
					then
						installCertificate "$1" "$CERT_PATH"
					fi
				done
				OPERA_BETA_PATH="/home/$user/.pki/nssdb"
			done
		done
	fi
	# end opera

	# thunderbird
	if [[ "$2" == *"t"* ]]
	then
		THUNDERBIRD_PATH="/home/*/.thunderbird/"

		for i in {1..2}
		do
			THUNDERBIRD_PROFILE_FILE="profiles.ini"
			THUNDERBIRD_PROFILES_FILE_PATH="${THUNDERBIRD_PATH}/${THUNDERBIRD_PROFILE_FILE}"

			for PROFILE in $THUNDERBIRD_PROFILES_FILE_PATH
			do
				# retrieve all profile paths
				THUNDERBIRD_PROFILE_PATHS="$(cat ${PROFILE} | grep ^Path= | sed 's/^Path=//')"

				for PROFILE_PATH in $THUNDERBIRD_PROFILE_PATHS
				do
					installCertificateUtil "$1" "$2" "${PROFILE_PATH}" "thunderbird" "${PROFILE}"
				done
			done

			THUNDERBIRD_PATH="/home/*/snap/*/*/.thunderbird"
		done
	fi
	# end thunderbird
}

main "$@"
