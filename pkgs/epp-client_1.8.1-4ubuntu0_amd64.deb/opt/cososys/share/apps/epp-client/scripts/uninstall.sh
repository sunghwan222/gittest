#!/bin/bash
#
# unistall.sh
#
# Created on: 29 Jun 2020
# Target: all Linux distros machines
#
# Copyright (c) 2020
#      CoSoSys SRL All rights reserved.
#
# Bash coding conventions and good practices:
#      https://github.com/icy/bash-coding-style#variable-names
#
# The shell script static analysis tool
#     https://www.shellcheck.net/
#     There are a couple checkers that are ignore in this script because they are false positives
#
# Endpoint Protector offers Data Loss Prevention for Windows, Mac and Linux, as well as
# Mobile Device Management for Android and iOS.
#

readonly _user="$(whoami)"
readonly _distro="$(lsb_release -i | cut -f 2-)"
readonly _epp_client_daemon=epp-client-daemon-d
readonly _service=/usr/sbin/service
readonly _yum=/usr/bin/yum
readonly _zypper=/usr/bin/zypper
readonly _dpkg=/usr/bin/dpkg

function remove_configuration_files {
    ${_service} ${_epp_client_daemon} stop
    killall -TERM epp-client
    rm -rf /opt/cososys/
    rm -rf /var/opt/cososys/
    rm -rf /var/log/epp-client/
    rm -f /etc/init.d/epp-client-daemon-d
    rm -f /etc/init.d/check-process.sh
    crontab -u root -l | sed 's/.*check-eppclient-process.sh.*$//g' | sudo crontab -u root -
    sudo killall check-eppclient-process.sh
    killall -TERM epp-client-daemon
    sudo rm -rf /var/log/epp-client
}

_epp_client_daemon_pid="$(ps faux | grep '/opt/cososys/sbin/epp-client-daemon' | grep -vw grep)"
_epp_client_daemon_pid="$(echo ${_epp_client_daemon_pid} | awk '{ print $2 }')"
if [ -n "${_epp_client_daemon_pid}" ]; then
    kill -s SIGUSR2 "${_epp_client_daemon_pid}"
    for _t in {01..05}; do
        sleep 1
    done
fi

## Force the user to run the script with root privileges
if [[ "${_user}" != root ]]; then
    exit
fi

## CentOS / RHEL
if [[ "${_distro}" == *CentOS* ]] || [[ "${_distro}" == *RedHatEnterpriseServer* ]]; then
    ${_yum} -y remove --disablerepo=* epp-client-config epp-client-cap-def epp-client cososys-filesystem cososys-curl
    remove_configuration_files 1>/dev/null 2>&1
    exit
fi

## Fedora / Oracle Server / Amazon
if [[ "${_distro}" == *Fedora* ]] || [[ "${_distro}" == *Oracle* ]] || [[ "${_distro}" == *Amazon* ]]; then
    ${_yum} -y remove --disablerepo=* epp-client-config epp-client-cap-def epp-client cososys-filesystem
    remove_configuration_files 1>/dev/null 2>&1
    exit
fi

## SLED / OpenSUSE
if [[ ${_distro_id^^} == "SUSE" ]] || [[ ${_distro_id} == "openSuse" ]]; then
    ${_zypper} -n remove epp-client-config epp-client-cap-def epp-client cososys-filesystem
    remove_configuration_files 1>/dev/null 2>&1
    exit
fi

## Ubuntu / Mint / Zorin / Debian
if [[ "${_distro}" == *Ubuntu* ]] || [[ "${_distro}" == *Mint* ]] || [[ "${_distro}" == *Zorin* ]] || [[ "${_distro}" == *Debian* ]]; then
    _epp_client_installed="$(${_dpkg} -l | grep epp-client | awk '{print $3}' | head -1)"
    if [ "${_epp_client_installed}" != "" ]; then
        ${_service} ${_epp_client_daemon} stop 1>/dev/null 2>&1
        ${_dpkg} --purge epp-client 1>/dev/null 2>&1
        ${_dpkg} --purge epp-client-config 1>/dev/null 2>&1
        ${_dpkg} --purge epp-client-cap-def 1>/dev/null 2>&1
        ${_dpkg} --purge cososys-filesystem 1>/dev/null 2>&1
        remove_configuration_files 1>/dev/null 2>&1
    fi
    exit
fi
