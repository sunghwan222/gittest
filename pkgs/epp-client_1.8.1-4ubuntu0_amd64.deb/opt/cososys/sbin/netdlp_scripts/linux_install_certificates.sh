#!/bin/bash
#
#  linux_install_certificates.sh
#
#  Created on: 26 Jun 2020
#
#  Copyright (c) 2020
#      CoSoSys SRL All rights reserved.
#
#  Bash coding conventions and good practices:
#      https://github.com/icy/bash-coding-style#variable-names
#
#  Parameter #1:
#      -l install  certificates
#      -u uninstall certificates
#
#  The list of browsers and email clients that can be used under netdlp can
#  to be configured also after the epp-client is installed.
#  there are many browsers / email clients that use in common the
#  NSS Shared DB for certificates. Install / uninstall for one of them will
#  be installed / uninstalled on all.
#

main() {
    # The functionality of this script can be configured using global below variables
    # that has the suffix "_cfg"

    if [[ ${_debug_mode_cfg} -eq 1 ]]; then
        installEppclientCertificate "$@"
    else
        installEppclientCertificate "$@" 1>/dev/null 2>&1
    fi

    echo "${_reset}"
    exit
}

###############################################################################################
# Implementation
###############################################################################################
readonly _debug_mode_cfg=0 # set debug mode using value 1

# Browsers
readonly _firefox_browser_cfg=1  # install / uninstall certificate for Firefox browser
readonly _chrome_browser_cfg=1   # install / uninstall certificate for Chrome browser
readonly _chromium_browser_cfg=1 # install / uninstall certificate for Chromium browser
readonly _opera_browser_cfg=1    # install / uninstall certificate for Opera browser

# Email clients
readonly _thunderbird_email_cfg=1   # install / uninstall certificate for Thunderbird email client
readonly _evolution_email_cfg=1     # install / uninstall certificate for Evolution email client
readonly _sylpheed_email_cfg=0      # install / uninstall certificate for Sylpheed email client
readonly _claws_email_cfg=0         # install / uninstall certificate for Claws email client
readonly _balsa_email_cfg=0         # install / uninstall certificate for Balsa email client
readonly _kmailInstallCertificate=0 # install / uninstall certificate for Kmail email client

# Global variable
readonly _current_user="$(whoami)"
readonly _machine_name="$(uname -n)"
readonly _certificate_file="/var/opt/cososys/epp-client/netdlp/cert.pem"
readonly _certificate_name="${_machine_name} - Endpoint Protector NetDLP"
readonly _cert_util="$(command -v certutil)"
readonly _users="$(who | cut -d' ' -f1)"
readonly _bold="$(tput bold)"
readonly _reset="$(tput sgr0)"

for _user in ${_users}; do _path_users+="$(eval echo ~"${_user}") "; done

####################################################################
# Function installEppclientCertificate for install / uninstall certificates
#   Parameter #1: "-l" install  or "-u" uninstall certificates
####################################################################
installEppclientCertificate() {

    # Force the user to run the script with root privileges
    if [[ ${_current_user} != root ]]; then
        echo "You must run this script with root privileges."
        echo "${_reset}"
        exit
    fi

    # at least a parameter is needed, keep more for compatibility with older version
    if [ "$#" -lt 1 ]; then
        echo "A parameter is needed (the others are neglected to keep compatibility with older version)."
        echo "The parameter must be:"
        echo "  -l add new certificates;"
        echo "  -u delete certificate;"
        echo "${_reset}"
        exit
    fi

    if [ "$1" != "-l" ] && [ "$1" != "-u" ]; then
        echo "First parameter must be -l (add new certificates), -u (delete existing certificates)."
        echo "${_reset}"
        exit
    fi

    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'installEppclientCertificate' function]${_reset}"

    #install / uninstall certificate for Firefox browser
    if [[ ${_firefox_browser_cfg} -eq 1 ]]; then firefoxInstallCertificate "$1"; fi

    #install / uninstall certificate for Chrome browser
    if [[ ${_chrome_browser_cfg} -eq 1 ]]; then chromeInstallCertificate "$1"; fi

    #install / uninstall certificate for Chromim browser
    if [[ ${_chromium_browser_cfg} -eq 1 ]]; then chromiumInstallCertificate "$1"; fi

    #install / uninstall certificate for Opera browser
    if [[ ${_opera_browser_cfg} -eq 1 ]]; then operaInstallCertificate "$1"; fi

    #install / uninstall certificate for Thunderbird email client
    if [[ ${_thunderbird_email_cfg} -eq 1 ]]; then thunderbirdInstallCertificate "$1"; fi

    #install / uninstall certificate for Evolution email client
    if [[ ${_evolution_email_cfg} -eq 1 ]]; then evolutionInstallCertificate "$1"; fi

    #install / uninstall certificate for Sylpheed email client
    if [[ ${_sylpheed_email_cfg} -eq 1 ]]; then sylpheedInstallCertificate "$1"; fi

    #install / uninstall certificate for Claws email client
    if [[ ${_claws_email_cfg} -eq 1 ]]; then clawsInstallCertificate "$1"; fi

    #install / uninstall certificate for Balsa email client
    if [[ ${_balsa_email_cfg} -eq 1 ]]; then balsaInstallCertificate "$1"; fi

    #install / uninstall certificate for Kmail email client
    if [[ ${_kmailInstallCertificate} -eq 1 ]]; then kmailInstallCertificate "$1"; fi

    echo
    echo -e "${_bold}[Exit 'installEppclientCertificate' function]${_reset}"
}

########################################
# function for add or delete certificate
#   parameter #1: "-l" or "-u"
#   parameter #2: _profile_path
########################################
installCertificate() {
    echo -e "${_bold}[Enter 'installCertificate' function]${_reset}"
    echo -e "  Current directory is '$2'"

    _working_path=$2

    if [[ "$(find "${_working_path}" -name cert9.db)" != '' ]]; then
        export NSS_DEFAULT_DB_TYPE=sql
    else
        export NSS_DEFAULT_DB_TYPE=dbm
    fi

    if [ "$1" == '-l' ]; then
        echo -e "  Add certificate '${_certificate_name}'."
        ${_cert_util} -A -n "\"${_certificate_name}\"" -t "TC,TC,TC" -d "${_working_path}" -i "${_certificate_file}"
        if [ $? -ne 0 ]; then
            echo -e "  Certificate '${_certificate_name}' was not installed."
        fi
    else
        echo -e "  Remove certificate '${_certificate_name}'."
        ${_cert_util} -D -d "${_working_path}" -n "\"${_certificate_name}\""
        if [ $? -ne 0 ]; then
            echo -e "  Certificate '${_certificate_name}' does not exist."
        fi
    fi

    echo -e "${_bold}[Exit 'installCertificate' function]${_reset}"
}

####################################################################
# Tools for install certificates  for Firefox and Thunderbird
#   parameter #1: "-l" or "-u"
#   parameter #2: profile path
#   parameter #3: thunderbird or firefox
#   parameter #4: the path of thunderbird or firefox profiles file
####################################################################
installCertificateUtil() {

    echo -e "${_bold}[Enter installCertificateUtil with parameters '$1' '$2' '$3' '$4']${_reset}"

    _profile_path=$2
    _profile_file_path=$4
    _profile_file_path="$(dirname "${_profile_file_path}")"

    if [ "$(echo "${_profile_path}" | grep "/")" == '' ]; then
        _profile_path="${_profile_file_path}/${_profile_path}"
    fi

    echo -e "  Profile path is ${_profile_path}."

    installCertificate "$1" "${_profile_path}"

    if [ "$1" == "-l" ]; then
        echo -e "  Certificate was added successfully for '$3'."
    fi

    if [ "$1" == "-u" ]; then
        echo -e "  Done. Certificate was deleted successfully for '$3'."
    fi

    echo -e "  Exit '$3' folder"
    echo -e "${_bold}[Exit installCertificateUtil]${_reset}"
}

#############################################################
# Function for add or delete certificate for Firefox browser
#   Parameter #1: "-l" or "-u"
#############################################################
firefoxInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'firefoxInstallCertificate' function]${_reset}"

    for _user in ${_path_users}; do
        _firefox_path="${_user}/.mozilla/firefox/"

        for i in {1..2}; do
            _firefox_profile_file="profiles.ini"
            _firefox_profile_file_path="${_firefox_path}/${_firefox_profile_file}"

            for _profile in ${_firefox_profile_file_path}; do
                if [[ ! -e ${_profile} ]]; then
                    continue
                fi
                # retrieve all profile paths
                _firefox_profile_paths="$(cat "${_profile}" | grep ^Path= | sed 's/^Path=//')"

                for _profile_path in ${_firefox_profile_paths}; do
                    echo "  installCertificateUtil $1 ${_profile_path} firefox ${_profile}"
                    installCertificateUtil "$1" "${_profile_path}" "firefox" "${_profile}"
                done
            done

            _firefox_path="{_user}/snap/*/*/.mozilla/firefox"
        done
    done

    echo -e "${_bold}[Exit 'firefoxInstallCertificate' function]${_reset}"
}

#############################################################
# Function for add or delete certificate for Chrome browser
#   Parameter #1: "-l" or "-u"
# Chrome browser uses the NSS Shared DB for certificates
#############################################################
chromeInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'chromeInstallCertificate' function]${_reset}"
    for _user in ${_path_users}; do
        _chrome_path="${_user}/snap/chrome/*/.pki/nssdb"
        for i in {1..2}; do
            for _cert_chrome_path in ${_chrome_path}; do
                if [[ -d ${_cert_chrome_path} ]]; then
                    echo "  installCertificate $1 ${_cert_chrome_path}"
                    installCertificate "$1" "${_cert_chrome_path}"
                fi
            done
            _chrome_path="${_user}/.pki/nssdb"
        done
    done
    echo -e "${_bold}[Exit 'chromeInstallCertificate' function]${_reset}"
}

#############################################################
# Function for add or delete certificate for Chromium browser
#   Parameter #1: "-l" or "-u"
# Chromium browser uses the NSS Shared DB for certificates
#############################################################
chromiumInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'chromiumInstallCertificate' function]${_reset}"
    for _user in ${_path_users}; do
        _chromium_path="${_user}/snap/chromium/*/.pki/nssdb"
        for i in {1..2}; do
            for _cert_chromium_path in ${_chromium_path}; do
                if [[ -d ${_cert_chromium_path} ]]; then
                    echo "  installCertificate $1 ${_cert_chromium_path}"
                    installCertificate "$1" "${_cert_chromium_path}"
                fi
            done
            _chromium_path="${_user}/.pki/nssdb"
        done
    done
    echo -e "${_bold}[Exit 'chromiumInstallCertificate' function]${_reset}"
}

#############################################################
# Function for add or delete certificate for Opera browser
#   Parameter #1: "-l" or "-u"
# Opera browser uses the NSS Shared DB for certificates
#############################################################
operaInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'operaInstallCertificate' function]${_reset}"

    for _user in ${_path_users}; do
        _opera_path="${_user}/snap/opera/*/.pki/nssdb"
        for i in {1..2}; do
            for _cert_opera_path in ${_opera_path}; do
                if [[ -d ${_cert_opera_path} ]]; then
                    echo "  installCertificate $1 ${_cert_opera_path}"
                    installCertificate "$1" "${_cert_opera_path}"
                fi
            done
            _opera_path="${_user}/.pki/nssdb"
        done
    done

    for _user in ${_path_users}; do
        _opera_developer_path="${_user}/snap/opera-developer/*/.pki/nssdb"
        for i in {1..2}; do
            for _cert_opera_path in ${_opera_developer_path}; do
                if [[ -d ${_cert_opera_path} ]]; then
                    echo "  installCertificate $1 ${_cert_opera_path}"
                    installCertificate "$1" "${_cert_opera_path}"
                fi
            done
            _opera_developer_path="${_user}/.pki/nssdb"
        done
    done

    for _user in ${_path_users}; do
        _opera_beta_path="${_user}/snap/opera-beta/*/.pki/nssdb"
        for i in {1..2}; do
            for _cert_opera_path in ${_opera_beta_path}; do
                if [[ -d ${_cert_opera_path} ]]; then
                    echo "  installCertificate $1 ${_cert_opera_path}"
                    installCertificate "$1" "${_cert_opera_path}"
                fi
            done
            _opera_beta_path="${_user}/.pki/nssdb"
        done
    done

    echo -e "${_bold}[Exit 'operaInstallCertificate' function]${_reset}"
}

######################################################################
# Function for add or delete certificate for Thunderbird email client
#   Parameter #1: "-l" or "-u"
######################################################################
thunderbirdInstallCertificate() {

    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'thunderbirdInstallCertificate' function]${_reset}"

    for _user in ${_path_users}; do
        _thunderbird_path="${_user}/.thunderbird/"

        for i in {1..2}; do
            _thunderbird_profile_file="profiles.ini"
            _thunderbird_profile_file_path="${_thunderbird_path}/${_thunderbird_profile_file}"

            for _profile in ${_thunderbird_profile_file_path}; do
                # retrieve all profile paths
                _thunderbird_profile_paths="$(cat "${_profile}" | grep ^Path= | sed 's/^Path=//')"

                for _profile_path in ${_thunderbird_profile_paths}; do
                    echo "installCertificateUtil $1 ${_profile_path} thunderbird ${_profile}"
                    installCertificateUtil "$1" "${_profile_path}" "thunderbird" "${_profile}"
                done
            done

            _thunderbird_path="${_user}/snap/*/*/.thunderbird"
        done
    done

    echo -e "${_bold}[Exit 'thunderbirdInstallCertificate' function]${_reset}"
}

###################################################################
# Function for add or delete certificate for Evolution email client
#   Parameter #1: "-l" or "-u"
# Evolution email uses the NSS Shared DB for certificates
###################################################################
evolutionInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'evolutionInstallEvolution' function]${_reset}"
    for _user in ${_path_users}; do
        if [[ -d ${_user}/.pki/nssdb ]]; then
            echo -e "  installCertificate $1 ${_user}/.pki/nssdb"
            installCertificate "$1" "${_user}/.pki/nssdb"
        fi
    done
    echo -e "${_bold}[Exit 'evolutionInstallCertificate' function]${_reset}"
}

###################################################################
# Function for add or delete certificate for Sylpheed email client
#   Parameter #1: "-l" or "-u"
#   Sylpheed is the default mail client in Lubuntu, Damn Small
#   Linux and some flavours of Puppy Linux.
###################################################################
sylpheedInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'sylpheedInstallCertificate' function]${_reset}"
    for _user in ${_path_users}; do
        if [[ -d ${_user}/.sylpheed-2.0/certs ]]; then
            echo -e "  installCertificate $1 ${_user}/.sylpheed-2.0/certs"
            installCertificate "$1" "${_user}/.sylpheed-2.0/certs"
        fi
    done
    echo -e "${_bold}[Exit 'sylpheedInstallCertificate' function]${_reset}"
}

###################################################################
# Function for add or delete certificate for Claws email client
#   Parameter #1: "-l" or "-u"
###################################################################
clawsInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'clawsInstallCertificate' function]${_reset}"
    for _user in ${_path_users}; do
        if [[ -d ${_user}/.claws-mail/certs ]]; then
            echo -e "  installCertificate $1 ${_user}/.claws-mail/certs"
            installCertificate "$1" "${_user}/.claws-mail/certs"
        fi
    done
    echo -e "${_bold}[Exit 'clawsInstallCertificate' function]${_reset}"
}

###################################################################
# Function for add or delete certificate for Balsa email client
#   Parameter #1: "-l" or "-u"
###################################################################
balsaInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter balsaInstallCertificate' function]${_reset}"
    for _user in ${_path_users}; do
        _balsa_path="${_user}/snap/balsa/*/.balsa/certificates"
        for i in {1..2}; do
            for _cert_balsa_path in ${_balsa_path}; do
                if [[ -d ${_cert_balsa_path} ]]; then
                    echo "  installCertificate $1 ${_cert_balsa_path}"
                    installCertificate "$1" "${_cert_balsa_path}"
                fi
            done
            _balsa_path="${_user}/.balsa/certificates"
        done
    done
    echo -e "${_bold}[Exit 'balsaInstallCertificate' function]${_reset}"
}

###################################################################
# Function for add or delete certificate for Kmail client
#   Parameter #1: "-l" or "-u"
###################################################################
kmailInstallCertificate() {
    echo
    echo "-------------------------------------------------------------"
    echo -e "${_bold}[Enter 'kmailInstallCertificate' function]${_reset}"
    echo -e "  installCertificate $1 /etc/ssl/certs"
    installCertificate "$1" "/etc/ssl/certs"
    echo -e "${_bold}[Exit 'kmailInstallCertificate' function]${_reset}"
}

main "$@"
